package com.faisal.meditation_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
